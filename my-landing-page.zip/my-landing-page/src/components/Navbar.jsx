import React from 'react'

const Navbar = () => {
  return (
    <nav className="bg-white shadow-lg py-4 px-6">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold text-blue-600">EduLearn</div>
        <div className="space-x-6">
          <a href="#home" className="text-gray-700 hover:text-blue-600">Home</a>
          <a href="#features" className="text-gray-700 hover:text-blue-600">Features</a>
          <a href="#courses" className="text-gray-700 hover:text-blue-600">Courses</a>
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          Sign Up
        </button>
      </div>
    </nav>
  )
}

export default Navbar