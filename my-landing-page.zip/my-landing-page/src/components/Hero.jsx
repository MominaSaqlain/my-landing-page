import React from 'react'

const Hero = () => {
  return (
    <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
      <div className="max-w-6xl mx-auto px-6 text-center">
        <h1 className="text-5xl font-bold mb-6">Learn Without Limits</h1>
        <p className="text-xl mb-8">
          Start your learning journey with thousands of courses from industry experts.
        </p>
        <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold text-lg hover:bg-gray-100">
          Join For Free
        </button>
      </div>
    </section>
  )
}

export default Hero