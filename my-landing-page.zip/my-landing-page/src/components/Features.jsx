import React from 'react'

const Features = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-gray-800 mb-12">
          Why Choose Us?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Expert Instructors</h3>
            <p className="text-gray-600">Learn from industry professionals</p>
          </div>
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Flexible Schedule</h3>
            <p className="text-gray-600">Study at your own pace</p>
          </div>
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Practical Projects</h3>
            <p className="text-gray-600">Build real-world projects</p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Features